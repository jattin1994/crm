<!DOCTYPE html>
<html>
<head>
	<title></title>
		<style>
		@media only screen and (min-width: 768px)
		{
	 		div#mail_box{
	 			margin-left:250px;
	 			margin-right:250px;
	 		} 
		}
	</style>
</head>
<body>
<p> Please click on button for verify your email id on crm website.</p>
<p><a href="{{$bodymessage}}">Button</a></p>
<p>CRM Portal</p>

</body>
</html>