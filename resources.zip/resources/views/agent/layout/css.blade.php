<!-- Bootstrap Core CSS -->
    <link href="{{URL::asset('theme/assets/css/bootstrap.min.css')}}" rel="stylesheet">
    <!-- Style Core CSS -->
    <link href="{{URL::asset('theme/assets/css/style.css')}}" rel="stylesheet">
    <!-- Animate Core CSS -->
    <link href="{{URL::asset('theme/assets/css/animate.css')}}" rel="stylesheet">
    <!-- Hover Core CSS -->
    <link href="{{URL::asset('theme/assets/css/hover.css')}}" rel="stylesheet">
    <!-- Bootstrap Select Picker -->
    <link href="{{URL::asset('theme/assets/css/bootstrap-select.min.css')}}" rel="stylesheet">
    <!-- Bootstrap Date Picker -->
    <link href="{{URL::asset('theme/assets/css/datepicker.min.css')}}" rel="stylesheet">
    <!-- Custom fonts for this template -->
    <link href="{{URL::asset('theme/assets/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css">
    <!-- Custom checkbox for this template -->
    <link href="{{URL::asset('theme/assets/css/pretty-checkbox.css')}}" rel="stylesheet" type="text/css" />
    <!-- layout css -->
    <link href="{{URL::asset('theme/assets/css/dashboard.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{URL::asset('theme/assets/css/dropzone.css')}}" rel="stylesheet" type="text/css" />
    <!-- layout css -->
    <link href="{!! asset('theme/assets/css/jquery.toast.min.css') !!}" rel="stylesheet" type="text/css" />
        <link href="{!! asset('theme/assets/css/responsive.css') !!}" rel="stylesheet" type="text/css" />