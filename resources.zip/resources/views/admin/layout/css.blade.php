<!-- Bootstrap Core CSS -->
    <link href="{{URL::asset('admin/assets/css/bootstrap.min.css')}}" rel="stylesheet">
    <!-- Style Core CSS -->
    <link href="{{URL::asset('admin/assets/css/style.css')}}" rel="stylesheet">
    <!-- Animate Core CSS -->
    <link href="{{URL::asset('admin/assets/css/animate.css')}}" rel="stylesheet">
    <!-- Hover Core CSS -->
    <link href="{{URL::asset('admin/assets/css/hover.css')}}" rel="stylesheet">
    <!-- Bootstrap Select Picker -->
    <link href="{{URL::asset('admin/assets/css/bootstrap-select.min.css')}}" rel="stylesheet">
    <!-- Bootstrap Date Picker -->
    <link href="{{URL::asset('admin/assets/css/datepicker.min.css')}}" rel="stylesheet">
    <!-- Custom fonts for this template -->
    <link href="{{URL::asset('admin/assets/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css">
    <!-- Custom checkbox for this template -->
    <link href="{{URL::asset('admin/assets/css/pretty-checkbox.css')}}" rel="stylesheet" type="text/css" />
    <!-- layout css -->
    <link href="{{URL::asset('admin/assets/css/dashboard.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{URL::asset('theme/assets/css/dropzone.css')}}" rel="stylesheet" type="text/css" />
    <!-- layout css -->
    <link href="{!! asset('theme/assets/css/jquery.toast.min.css') !!}" rel="stylesheet" type="text/css" />
        <link href="{!! asset('admin/assets/css/responsive.css') !!}" rel="stylesheet" type="text/css" />